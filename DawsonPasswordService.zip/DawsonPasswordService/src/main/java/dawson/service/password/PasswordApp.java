/**
 * Author: Jonathan Dawson
 * Created: 08/03/2018
 */
package dawson.service.password;

import org.springframework.boot.SpringApplication;

public class PasswordApp
{
    public static void main(String[] args)
    {
        SpringApplication.run(PasswordService.class, args);
    }
}
