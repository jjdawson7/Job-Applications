/**
 * Author: Jonathan Dawson
 * Created: 08/03/2018
 */
package dawson.service.password;

import java.util.function.Function;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RequestMapping(path = "/", consumes = "text/plain", produces = "text/plain")
@RestController
public class PasswordService
{
    public static final Function<String, String> LENGTH_RULE = (String p) -> {
        if (p == null)
        {
            return "Password cannot be null.";
        }
        if ((p.length() < 5) || (p.length() > 12))
        {
            return "Password must be between 5 and 12 characters, inclusive.";
        }
        return null;
    };

    public static final Function<String, String> LOWER_CASE_DIGIT_RULE = (String p) -> {
        boolean hasLowerCase = false;
        boolean hasDigit = false;

        for (int i = 0; i < p.length(); i++)
        {
            char c = p.charAt(i);
            boolean isLowerCase = Character.isLowerCase(c);
            boolean isDigit = Character.isDigit(c);
            if ((isLowerCase == false) &&
                (isDigit == false))
            {
                return "Password must contain only lower case or numeric characters.";
            }
            hasLowerCase |= isLowerCase;
            hasDigit |= isDigit;
        }

        if (hasLowerCase == false)
        {
            return "Password must contain at least one lower case character.";
        }
        if (hasDigit == false)
        {
            return "Password must contain at least one digit.";
        }
        return null;
    };

    public static final Function<String, String> NO_REPEAT_RULE = (String p) -> {
        int halfLength = p.length() / 2;
        for (int size = 2; size <= halfLength; size++)
        {
            int doubleSize = size * 2;
            for (int j = 0; j <= p.length() - doubleSize; j++)
            {
                int i = 0;
                for (; i < size; i++)
                {
                    char c1 = p.charAt(j + i);
                    char c2 = p.charAt(j + size + i);
                    if (c1 != c2)
                    {
                        break;
                    }
                }
                if (i == size) //if matching sequence found
                {
                    return "Password cannot contain any sequence of characters immediately followed by the same sequence.";
                }
            }
        }
        return null;
    };

    public PasswordService()
    {
        rules = new Function[] {LENGTH_RULE, LOWER_CASE_DIGIT_RULE, NO_REPEAT_RULE};
    }

    @RequestMapping(method = {RequestMethod.POST}, path = "/validate")
    public String validate(String password)
    {
        for (Function<String, String> rule : rules)
        {
            String response = rule.apply(password);
            if (response != null)
            {
                return response;
            }
        }
        return "";
    }

    protected final Function<String, String>[] rules;
}
