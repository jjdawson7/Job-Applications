/**
 * Author: Jonathan Dawson
 * Created: 08/03/2018
 */
package dawson.service.password;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class PasswordServiceControllerTest
{
    @Test
    public void incorrectURLShouldFail() throws Exception
    {
        mvc.perform(MockMvcRequestBuilders.post("/validat").param("password", "hello6").contentType(
                                                                                                    MediaType.TEXT_PLAIN))
           .andExpect(status().is(HttpStatus.NOT_FOUND.value()));
    }

    @Test
    public void validateShouldSucceedWhenValidPassword() throws Exception
    {
        mvc.perform(MockMvcRequestBuilders.post("/validate").param("password", "hello6").contentType(
                                                                                                     MediaType.TEXT_PLAIN))
           .andExpect(status().isOk()).andExpect(content().string(""));

        mvc.perform(MockMvcRequestBuilders.post("/validate").param("password", "5goodday5").contentType(
                                                                                                        MediaType.TEXT_PLAIN))
           .andExpect(status().isOk()).andExpect(content().string(""));
    }

    @Test
    public void validateShouldFailWhenInvalidPassword() throws Exception
    {
        mvc.perform(MockMvcRequestBuilders.post("/validate").param("password", "h6").contentType(
                                                                                                 MediaType.TEXT_PLAIN))
           .andExpect(status().isOk()).andExpect(content().string("Password must be between 5 and 12 characters, inclusive."));

        mvc.perform(MockMvcRequestBuilders.post("/validate").param("password", "LkjoqiwjKLJ2").contentType(
                                                                                                           MediaType.TEXT_PLAIN))
           .andExpect(status().isOk()).andExpect(content().string("Password must contain only lower case or numeric characters."));
    }

    @Autowired
    protected MockMvc mvc;
}
