/**
 * Author: Jonathan Dawson
 * Created: 08/03/2018
 */
package dawson.service.password;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PasswordServiceTest
{
    @Before
    public void setUp()
    {
        ps = new PasswordService();
    }

    @Test
    public void lengthRuleShouldReturnCorrectMessages()
    {
        assertEquals("null", ps.validate(null), "Password cannot be null.");
        assertEquals("length", ps.validate(""), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("a"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("ab"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("abc"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("abcd"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("abcdefghijklm"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("abcdefghijklmnopqrst"), "Password must be between 5 and 12 characters, inclusive.");
        assertEquals("length", ps.validate("abcdefghijklmnopqrstuvwxyz"),
                     "Password must be between 5 and 12 characters, inclusive.");
    }

    @Test
    public void lowerCaseDigitRuleShouldReturnCorrectMessages()
    {
        assertEquals("digit", ps.validate("abcde"), "Password must contain at least one digit.");
        assertEquals("digit", ps.validate("abcdefghijkl"), "Password must contain at least one digit.");
        assertEquals("lower case", ps.validate("67890"), "Password must contain at least one lower case character.");
        assertEquals("lower case", ps.validate("123456789012"), "Password must contain at least one lower case character.");
        assertEquals("upper case", ps.validate("ABCDEFGH"), "Password must contain only lower case or numeric characters.");
        assertEquals("symbol", ps.validate("@(*&#@&^"), "Password must contain only lower case or numeric characters.");
    }

    @Test
    public void sequenceRuleShouldReturnCorrectMessages()
    {
        assertEquals("sequence", ps.validate("hellohello7"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("heheoir8"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("iue45hehe"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("iueheyheywe5"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("uetheytheyw5"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("theirtheir5"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("5theirtheir"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
        assertEquals("sequence", ps.validate("their9their9"),
                     "Password cannot contain any sequence of characters immediately followed by the same sequence.");
    }

    @Test
    public void validateShouldReturnEmptyWhenPasswordIsValid()
    {
        assertEquals("valid", ps.validate("45password23"), "");
        assertEquals("valid", ps.validate("password23"), "");
        assertEquals("valid", ps.validate("23password"), "");
        assertEquals("valid", ps.validate("p2a3s4s5"), "");
        assertEquals("valid", ps.validate("2a3s4"), "");
    }

    protected PasswordService ps;
}
