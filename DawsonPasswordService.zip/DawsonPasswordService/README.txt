Instructions for running Dawson password validation service:

1. Unzip "DawsonPasswordService.zip" to local directory of your choice.

2. Import project into Eclipse 4.5+.

3. Maven should automatically recognize and configure the build environment.

4. Build project (if not automatic).

5. Find "dawson.service.password.PasswordApp".

6. Run "PasswordApp" as a "Java Application".  This option should automatically show up when Right-clicking on the class under the "Run As" menu.  You can also find the "Run As" menu under the Eclipse "Run" menu.

7. Open Firefox or other browser.

8. Use "RESTClient" or other RESTful client.

9. Using RESTful client, "POST" an HTTP request to "http://localhost:8080/validate?password=testword938"
